#include "NvBlastExtStressGpuMultilevel.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <utility>

namespace Nv { namespace Blast { namespace Multilevel {
namespace {
constexpr uint32_t Width = 6;
using Block = std::array<double, Width * Width>;

struct Blocks
{
    uint32_t rows = 0, columns = 0;
    std::vector<uint32_t> offsets{0}, indices;
    std::vector<Block> values;
};

uint32_t index(size_t value)
{
    if (value > std::numeric_limits<uint32_t>::max())
        throw std::runtime_error("Multilevel matrix exceeds index representation");
    return static_cast<uint32_t>(value);
}

Block transposed(const Block& a)
{
    Block result{};
    for (uint32_t i = 0; i < Width; ++i)
        for (uint32_t j = 0; j < Width; ++j)
            result[i * Width + j] = a[j * Width + i];
    return result;
}

void multiplyAdd(Block& output, const Block& a, const Block& b, double scale = 1)
{
    for (uint32_t i = 0; i < Width; ++i)
        for (uint32_t k = 0; k < Width; ++k)
        {
            const double value = scale * a[i * Width + k];
            if (value == 0) continue;
            for (uint32_t j = 0; j < Width; ++j)
                output[i * Width + j] += value * b[k * Width + j];
        }
}

std::vector<double> cholesky(const std::vector<double>& a, uint32_t n)
{
    std::vector<double> lower(size_t(n) * n, 0);
    for (uint32_t i = 0; i < n; ++i)
        for (uint32_t j = 0; j <= i; ++j)
        {
            double value = a[size_t(i) * n + j];
            for (uint32_t k = 0; k < j; ++k)
                value -= lower[size_t(i) * n + k] * lower[size_t(j) * n + k];
            if (i == j)
            {
                if (!(value > 0) || !std::isfinite(value))
                    throw std::runtime_error("Multilevel Cholesky has a nonpositive pivot");
                lower[size_t(i) * n + j] = std::sqrt(value);
            }
            else lower[size_t(i) * n + j] = value / lower[size_t(j) * n + j];
        }
    return lower;
}

std::vector<double> inverseLower(const std::vector<double>& lower, uint32_t n)
{
    std::vector<double> inverse(size_t(n) * n, 0);
    for (uint32_t column = 0; column < n; ++column)
        for (uint32_t row = 0; row < n; ++row)
        {
            double value = row == column ? 1 : 0;
            for (uint32_t k = 0; k < row; ++k)
                value -= lower[size_t(row) * n + k] * inverse[size_t(k) * n + column];
            inverse[size_t(row) * n + column] = value / lower[size_t(row) * n + row];
        }
    return inverse;
}

std::vector<double> inversePositive(const std::vector<double>& matrix, uint32_t n)
{
    const auto lowerInverse = inverseLower(cholesky(matrix, n), n);
    std::vector<double> result(size_t(n) * n, 0);
    for (uint32_t i = 0; i < n; ++i)
        for (uint32_t j = 0; j < n; ++j)
            for (uint32_t k = std::max(i, j); k < n; ++k)
                result[size_t(i) * n + j] += lowerInverse[size_t(k) * n + i] * lowerInverse[size_t(k) * n + j];
    return result;
}

Blocks fromScalar(const Matrix& matrix)
{
    if (matrix.rows == 0 || matrix.rows % Width || matrix.columns % Width ||
        matrix.offsets.size() != size_t(matrix.rows) + 1 || matrix.offsets.front() != 0 ||
        matrix.offsets.back() != matrix.values.size() || matrix.indices.size() != matrix.values.size() ||
        !std::is_sorted(matrix.offsets.begin(), matrix.offsets.end()))
        throw std::runtime_error("Invalid multilevel scalar CSR");
    Blocks result;
    result.rows = matrix.rows / Width;
    result.columns = matrix.columns / Width;
    std::vector<uint32_t> touched;
    std::vector<int64_t> stamp(result.columns, -1);
    std::vector<Block> accumulator(result.columns);
    for (uint32_t row = 0; row < result.rows; ++row)
    {
        touched.clear();
        for (uint32_t r = 0; r < Width; ++r)
            for (uint32_t j = matrix.offsets[row * Width + r]; j < matrix.offsets[row * Width + r + 1]; ++j)
            {
                const uint32_t scalarColumn = matrix.indices[j];
                if (scalarColumn >= matrix.columns || !std::isfinite(matrix.values[j]))
                    throw std::runtime_error("Invalid multilevel column or value");
                const uint32_t column = scalarColumn / Width;
                if (stamp[column] != row)
                {
                    stamp[column] = row;
                    accumulator[column] = {};
                    touched.push_back(column);
                }
                accumulator[column][r * Width + scalarColumn % Width] += matrix.values[j];
            }
        std::sort(touched.begin(), touched.end());
        for (uint32_t column : touched)
        {
            result.indices.push_back(column);
            result.values.push_back(accumulator[column]);
        }
        result.offsets.push_back(index(result.indices.size()));
    }
    return result;
}

Matrix toScalar(const Blocks& blocks)
{
    Matrix result;
    result.rows = index(size_t(blocks.rows) * Width);
    result.columns = index(size_t(blocks.columns) * Width);
    result.offsets.push_back(0);
    for (uint32_t row = 0; row < blocks.rows; ++row)
        for (uint32_t r = 0; r < Width; ++r)
        {
            for (uint32_t j = blocks.offsets[row]; j < blocks.offsets[row + 1]; ++j)
                for (uint32_t c = 0; c < Width; ++c)
                {
                    const double value = blocks.values[j][r * Width + c];
                    if (!std::isfinite(value))
                        throw std::runtime_error("Nonfinite multilevel coefficient");
                    // Omit exact zeros only. No magnitude-based coefficient dropping.
                    if (value == 0) continue;
                    result.indices.push_back(blocks.indices[j] * Width + c);
                    result.values.push_back(value);
                }
            result.offsets.push_back(index(result.indices.size()));
        }
    return result;
}

Blocks transpose(const Blocks& a)
{
    Blocks result;
    result.rows = a.columns;
    result.columns = a.rows;
    result.offsets.assign(size_t(result.rows) + 1, 0);
    for (uint32_t column : a.indices) ++result.offsets[column + 1];
    for (uint32_t i = 0; i < result.rows; ++i) result.offsets[i + 1] += result.offsets[i];
    result.indices.resize(a.indices.size());
    result.values.resize(a.values.size());
    auto cursor = result.offsets;
    for (uint32_t row = 0; row < a.rows; ++row)
        for (uint32_t j = a.offsets[row]; j < a.offsets[row + 1]; ++j)
        {
            const uint32_t destination = cursor[a.indices[j]]++;
            result.indices[destination] = row;
            result.values[destination] = transposed(a.values[j]);
        }
    return result;
}

Blocks multiply(const Blocks& a, const Blocks& b)
{
    if (a.columns != b.rows) throw std::runtime_error("Multilevel product dimensions");
    Blocks result;
    result.rows = a.rows;
    result.columns = b.columns;
    std::vector<int64_t> stamp(b.columns, -1);
    std::vector<Block> accumulator(b.columns);
    std::vector<uint32_t> touched;
    for (uint32_t row = 0; row < a.rows; ++row)
    {
        touched.clear();
        for (uint32_t j = a.offsets[row]; j < a.offsets[row + 1]; ++j)
            for (uint32_t k = b.offsets[a.indices[j]]; k < b.offsets[a.indices[j] + 1]; ++k)
            {
                const uint32_t column = b.indices[k];
                if (stamp[column] != row)
                {
                    stamp[column] = row;
                    accumulator[column] = {};
                    touched.push_back(column);
                }
                multiplyAdd(accumulator[column], a.values[j], b.values[k]);
            }
        std::sort(touched.begin(), touched.end());
        for (uint32_t column : touched)
        {
            result.indices.push_back(column);
            result.values.push_back(accumulator[column]);
        }
        result.offsets.push_back(index(result.indices.size()));
    }
    return result;
}

Blocks add(const Blocks& a, const Blocks& b, double scaleA, double scaleB)
{
    if (a.rows != b.rows || a.columns != b.columns)
        throw std::runtime_error("Multilevel sum dimensions");
    Blocks result;
    result.rows = a.rows;
    result.columns = a.columns;
    for (uint32_t row = 0; row < a.rows; ++row)
    {
        uint32_t ai = a.offsets[row], bi = b.offsets[row];
        while (ai < a.offsets[row + 1] || bi < b.offsets[row + 1])
        {
            const uint32_t ac = ai < a.offsets[row + 1] ? a.indices[ai] : UINT32_MAX;
            const uint32_t bc = bi < b.offsets[row + 1] ? b.indices[bi] : UINT32_MAX;
            const uint32_t column = std::min(ac, bc);
            Block value{};
            for (uint32_t k = 0; k < Width * Width; ++k)
                value[k] = (ac == column ? scaleA * a.values[ai][k] : 0) +
                           (bc == column ? scaleB * b.values[bi][k] : 0);
            if (ac == column) ++ai;
            if (bc == column) ++bi;
            result.indices.push_back(column);
            result.values.push_back(value);
        }
        result.offsets.push_back(index(result.indices.size()));
    }
    return result;
}

struct Diagonal
{
    Blocks inverse;
    std::vector<Block> whitening;
};

Diagonal diagonal(const Blocks& a)
{
    Diagonal result;
    result.inverse.rows = result.inverse.columns = a.rows;
    for (uint32_t row = 0; row < a.rows; ++row)
    {
        const auto begin = a.indices.begin() + a.offsets[row];
        const auto end = a.indices.begin() + a.offsets[row + 1];
        const auto found = std::lower_bound(begin, end, row);
        if (found == end || *found != row) throw std::runtime_error("Missing diagonal block");
        const Block& block = a.values[found - a.indices.begin()];
        const std::vector<double> dense(block.begin(), block.end());
        const auto white = inverseLower(cholesky(dense, Width), Width);
        Block whitening{};
        std::copy(white.begin(), white.end(), whitening.begin());
        Block inverse{};
        multiplyAdd(inverse, transposed(whitening), whitening);
        result.whitening.push_back(whitening);
        result.inverse.indices.push_back(row);
        result.inverse.values.push_back(inverse);
        result.inverse.offsets.push_back(index(result.inverse.indices.size()));
    }
    return result;
}

double eigenvalueUpperBound(const Blocks& a, const std::vector<Block>& white)
{
    // For symmetric H = L^-1 A L^-T, lambda_max(H) <= rho(abs(H)).
    // For any positive v, max_i(abs(H)*v)_i/v_i bounds that Perron root.
    // A few positive power steps tighten the bound without assuming an
    // under-estimated Rayleigh quotient is a safe smoothing parameter.
    Blocks absolute = a;
    for (uint32_t row = 0; row < a.rows; ++row)
        for (uint32_t j = a.offsets[row]; j < a.offsets[row + 1]; ++j)
        {
            Block intermediate{}, value{};
            multiplyAdd(intermediate, white[row], a.values[j]);
            multiplyAdd(value, intermediate, transposed(white[a.indices[j]]));
            for (double& entry : value) entry = std::abs(entry);
            absolute.values[j] = value;
        }
    std::vector<double> v(size_t(a.rows) * Width, 1), next(v.size());
    double best = std::numeric_limits<double>::infinity();
    for (uint32_t step = 0; step < 12; ++step)
    {
        std::fill(next.begin(), next.end(), 0);
        for (uint32_t row = 0; row < absolute.rows; ++row)
            for (uint32_t j = absolute.offsets[row]; j < absolute.offsets[row + 1]; ++j)
                for (uint32_t r = 0; r < Width; ++r)
                    for (uint32_t c = 0; c < Width; ++c)
                        next[row * Width + r] += absolute.values[j][r * Width + c] * v[absolute.indices[j] * Width + c];
        double upper = 0, maximum = 0;
        for (size_t i = 0; i < v.size(); ++i)
        {
            if (!(v[i] > 0) || !std::isfinite(next[i])) throw std::runtime_error("Invalid spectral bound");
            upper = std::max(upper, next[i] / v[i]);
            maximum = std::max(maximum, next[i]);
        }
        if (!(maximum > 0) || !std::isfinite(upper)) throw std::runtime_error("Zero spectral bound");
        best = std::min(best, upper);
        for (size_t i = 0; i < v.size(); ++i)
            v[i] = std::max(next[i] / maximum, 1e-12);  // any positive test vector gives a bound
    }
    return best * 1.05;  // margin for floating-point construction/reductions
}

struct Qr
{
    std::vector<double> q;
    Block r{};
};

Qr qr(const std::vector<double>& basis, uint32_t rows)
{
    if (rows < Width || basis.size() != size_t(rows) * Width)
        throw std::runtime_error("Rigid basis dimensions");
    Qr result;
    result.q = basis;
    // Twice-reorthogonalized modified Gram-Schmidt, only six columns. Column
    // signs may differ from LAPACK; those are coordinate choices, not loads.
    for (uint32_t column = 0; column < Width; ++column)
    {
        for (uint32_t pass = 0; pass < 2; ++pass)
            for (uint32_t previous = 0; previous < column; ++previous)
            {
                double dot = 0;
                for (uint32_t row = 0; row < rows; ++row)
                    dot += result.q[row * Width + previous] * result.q[row * Width + column];
                result.r[previous * Width + column] += dot;
                for (uint32_t row = 0; row < rows; ++row)
                    result.q[row * Width + column] -= dot * result.q[row * Width + previous];
            }
        double norm = 0;
        for (uint32_t row = 0; row < rows; ++row) norm = std::hypot(norm, result.q[row * Width + column]);
        if (!(norm > 0) || !std::isfinite(norm)) throw std::runtime_error("Rank-deficient rigid basis");
        result.r[column * Width + column] = norm;
        for (uint32_t row = 0; row < rows; ++row) result.q[row * Width + column] /= norm;
    }
    return result;
}

struct Aggregation
{
    Blocks tentative;
    std::vector<double> coarseBasis;
    double reconstructionError = 0;
};

Aggregation aggregate(const Blocks& a, const std::vector<double>& basis)
{
    std::vector<int64_t> owner(a.rows, -1);
    std::vector<std::vector<uint32_t>> groups;
    for (uint32_t seed = 0; seed < a.rows; ++seed)
    {
        if (owner[seed] >= 0) continue;
        std::vector<uint32_t> group{seed};
        owner[seed] = groups.size();
        for (size_t next = 0; next < group.size() && group.size() < 8; ++next)
            for (uint32_t j = a.offsets[group[next]]; j < a.offsets[group[next] + 1] && group.size() < 8; ++j)
            {
                const uint32_t neighbor = a.indices[j];
                if (owner[neighbor] >= 0) continue;
                owner[neighbor] = groups.size();
                group.push_back(neighbor);
            }
        groups.push_back(std::move(group));
    }
    if (groups.size() >= a.rows) throw std::runtime_error("Aggregation did not reduce component");
    Aggregation result;
    result.tentative.rows = a.rows;
    result.tentative.columns = index(groups.size());
    result.tentative.indices.resize(a.rows);
    result.tentative.values.resize(a.rows);
    result.tentative.offsets.resize(size_t(a.rows) + 1);
    for (uint32_t row = 0; row <= a.rows; ++row) result.tentative.offsets[row] = row;
    double error2 = 0, norm2 = 0;
    for (uint32_t groupId = 0; groupId < groups.size(); ++groupId)
    {
        const auto& group = groups[groupId];
        std::vector<double> local;
        for (uint32_t node : group)
            local.insert(local.end(), basis.begin() + size_t(node) * Width * Width,
                         basis.begin() + size_t(node + 1) * Width * Width);
        const Qr factor = qr(local, index(group.size() * Width));
        result.coarseBasis.insert(result.coarseBasis.end(), factor.r.begin(), factor.r.end());
        for (uint32_t i = 0; i < group.size(); ++i)
        {
            const uint32_t node = group[i];
            Block qBlock{};
            std::copy_n(factor.q.begin() + size_t(i) * Width * Width, Width * Width, qBlock.begin());
            result.tentative.indices[node] = groupId;
            result.tentative.values[node] = qBlock;
            Block reconstructed{};
            multiplyAdd(reconstructed, qBlock, factor.r);
            for (uint32_t k = 0; k < Width * Width; ++k)
            {
                const double expected = basis[size_t(node) * Width * Width + k];
                const double error = reconstructed[k] - expected;
                error2 += error * error;
                norm2 += expected * expected;
            }
        }
    }
    result.reconstructionError = std::sqrt(error2 / norm2);
    if (!(result.reconstructionError < 1e-12)) throw std::runtime_error("Rigid basis reconstruction failed");
    return result;
}

std::vector<double> dense(const Blocks& a)
{
    const uint32_t n = index(size_t(a.rows) * Width);
    std::vector<double> result(size_t(n) * n, 0);
    for (uint32_t row = 0; row < a.rows; ++row)
        for (uint32_t j = a.offsets[row]; j < a.offsets[row + 1]; ++j)
            for (uint32_t r = 0; r < Width; ++r)
                for (uint32_t c = 0; c < Width; ++c)
                    result[size_t(row * Width + r) * n + a.indices[j] * Width + c] = a.values[j][r * Width + c];
    return result;
}
} // namespace

Hierarchy buildConnected(const Matrix& matrix, const std::vector<double>& initialBasis, bool freeComponent)
{
    const auto start = std::chrono::steady_clock::now();
    if (matrix.rows != matrix.columns || initialBasis.size() != size_t(matrix.rows) * Width)
        throw std::runtime_error("Multilevel component dimensions");
    Hierarchy result;
    Blocks current = fromScalar(matrix);
    std::vector<double> basis = initialBasis;
    while (current.rows >= 30)
    {
        const auto diagonalData = diagonal(current);
        const double bound = eigenvalueUpperBound(current, diagonalData.whitening);
        const auto aggregation = aggregate(current, basis);
        result.maximumBasisReconstructionError = std::max(result.maximumBasisReconstructionError, aggregation.reconstructionError);
        const double omega = 1 / bound;
        const Blocks smoothed = add(aggregation.tentative,
            multiply(diagonalData.inverse, multiply(current, aggregation.tentative)), 1, -omega);
        const Blocks restriction = transpose(smoothed);
        Blocks next = multiply(restriction, multiply(current, smoothed));
        next = add(next, transpose(next), .5, .5);
        result.levels.push_back({toScalar(current), toScalar(diagonalData.inverse),
                                 toScalar(smoothed), toScalar(restriction), omega, bound});
        current = std::move(next);
        basis = aggregation.coarseBasis;
    }
    result.coarseRows = index(size_t(current.rows) * Width);
    auto coarse = dense(current);
    std::vector<double> q;
    if (freeComponent)
    {
        q = qr(basis, result.coarseRows).q;
        for (uint32_t i = 0; i < result.coarseRows; ++i)
            for (uint32_t j = 0; j < result.coarseRows; ++j)
                for (uint32_t k = 0; k < Width; ++k)
                    coarse[size_t(i) * result.coarseRows + j] += q[i * Width + k] * q[j * Width + k];
    }
    result.coarseInverse = inversePositive(coarse, result.coarseRows);
    if (freeComponent)
    {
        // Project on both sides without materializing another dense projector.
        const uint32_t n = result.coarseRows;
        for (uint32_t column = 0; column < n; ++column)
            for (uint32_t k = 0; k < Width; ++k)
            {
                double dot = 0;
                for (uint32_t row = 0; row < n; ++row) dot += q[row * Width + k] * result.coarseInverse[size_t(row) * n + column];
                for (uint32_t row = 0; row < n; ++row) result.coarseInverse[size_t(row) * n + column] -= q[row * Width + k] * dot;
            }
        for (uint32_t row = 0; row < n; ++row)
            for (uint32_t k = 0; k < Width; ++k)
            {
                double dot = 0;
                for (uint32_t column = 0; column < n; ++column) dot += result.coarseInverse[size_t(row) * n + column] * q[column * Width + k];
                for (uint32_t column = 0; column < n; ++column) result.coarseInverse[size_t(row) * n + column] -= dot * q[column * Width + k];
            }
    }
    result.setupMilliseconds = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
    return result;
}

}}}
