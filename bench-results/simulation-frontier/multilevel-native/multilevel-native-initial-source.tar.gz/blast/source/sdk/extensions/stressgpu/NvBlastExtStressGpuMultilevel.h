#pragma once

#include <cstdint>
#include <vector>

namespace Nv { namespace Blast { namespace Multilevel {

// Host construction data. Runtime integration supplies the physical operator;
// these types do not own a CUDA context or change force/topology semantics.
struct Matrix
{
    uint32_t rows = 0, columns = 0;
    std::vector<uint32_t> offsets, indices;
    std::vector<double> values;
};

struct Level
{
    Matrix matrix, inverseDiagonal, prolongation, restriction;
    double omega = 0;
    double eigenvalueUpperBound = 0;
};

struct Hierarchy
{
    std::vector<Level> levels;
    uint32_t coarseRows = 0;
    std::vector<double> coarseInverse;  // row-major, projected for a free island
    double setupMilliseconds = 0;
    double maximumBasisReconstructionError = 0;
};

// Build one connected component. The input has six scalar rows per node; basis
// is row-major (matrix.rows x 6), in the same mass-scaled coordinates. Free
// components must supply their exact six rigid modes. Anchored components
// supply the corresponding near-null modes. Callers must use the current exact
// component partition; hierarchy reuse does not authorize stale island labels.
// Numerical failures throw; no coefficients, interactions or loads are clipped.
Hierarchy buildConnected(const Matrix& matrix, const std::vector<double>& basis,
                         bool freeComponent);

}}}
