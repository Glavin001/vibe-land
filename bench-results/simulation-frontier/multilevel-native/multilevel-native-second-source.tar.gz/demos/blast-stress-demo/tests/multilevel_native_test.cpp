// Independent algebraic checks: transformed spring chains have six exact
// null modes, while an anchored endpoint makes the same operator positive.
#include "NvBlastExtStressGpuMultilevel.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

using namespace Nv::Blast::Multilevel;
using Values = std::vector<double>;

void require(bool condition, const char* message)
{
    if (!condition) throw std::runtime_error(message);
}

double norm(const Values& values)
{
    double result = 0;
    for (double value : values) result = std::hypot(result, value);
    return result;
}

void close(const Values& a, const Values& b, double tolerance, const char* message)
{
    require(a.size() == b.size(), "Comparison dimensions");
    Values error(a.size());
    for (size_t i = 0; i < a.size(); ++i) error[i] = a[i] - b[i];
    const double scale = std::max({norm(a), norm(b), 1e-100});
    if (!(norm(error) <= tolerance * scale))
    {
        std::fprintf(stderr, "%s: relative error %.12g\n", message, norm(error) / scale);
        throw std::runtime_error(message);
    }
}

Matrix sparse(const Values& dense, uint32_t rows, uint32_t columns)
{
    Matrix a{rows, columns, {0}, {}, {}};
    for (uint32_t row = 0; row < rows; ++row)
    {
        for (uint32_t column = 0; column < columns; ++column)
            if (dense[size_t(row) * columns + column] != 0)
            {
                a.indices.push_back(column);
                a.values.push_back(dense[size_t(row) * columns + column]);
            }
        a.offsets.push_back(a.values.size());
    }
    return a;
}

Values multiplyVector(const Matrix& a, const Values& x)
{
    require(x.size() == a.columns, "Apply dimensions");
    Values y(a.rows, 0);
    for (uint32_t row = 0; row < a.rows; ++row)
        for (uint32_t j = a.offsets[row]; j < a.offsets[row + 1]; ++j)
            y[row] += a.values[j] * x[a.indices[j]];
    return y;
}

Values dense(const Matrix& a)
{
    Values result(size_t(a.rows) * a.columns, 0);
    for (uint32_t row = 0; row < a.rows; ++row)
        for (uint32_t j = a.offsets[row]; j < a.offsets[row + 1]; ++j)
            result[size_t(row) * a.columns + a.indices[j]] += a.values[j];
    return result;
}

Values transpose(const Values& a, uint32_t rows, uint32_t columns)
{
    Values result(a.size());
    for (uint32_t i = 0; i < rows; ++i)
        for (uint32_t j = 0; j < columns; ++j)
            result[size_t(j) * rows + i] = a[size_t(i) * columns + j];
    return result;
}

Values product(const Values& a, const Values& b, uint32_t n)
{
    Values result(size_t(n) * n, 0);
    for (uint32_t i = 0; i < n; ++i)
        for (uint32_t k = 0; k < n; ++k)
            for (uint32_t j = 0; j < n; ++j)
                result[size_t(i) * n + j] += a[size_t(i) * n + k] * b[size_t(k) * n + j];
    return result;
}

struct Chain { Matrix a; Values basis; };
Chain chain(uint32_t nodes, bool anchored)
{
    const uint32_t n = nodes * 6;
    Values a(size_t(n) * n, 0), basis(size_t(n) * 6, 0);
    std::vector<std::array<double, 36>> frames(nodes);
    for (uint32_t node = 0; node < nodes; ++node)
    {
        auto& frame = frames[node];
        const double angular = 1 + .1 * (node % 7), linear = .5 + .1 * (node % 11);
        for (uint32_t d = 0; d < 6; ++d)
        {
            const double scale = d < 3 ? angular : linear;
            frame[d * 6 + d] = scale;
            basis[size_t(node * 6 + d) * 6 + d] = 1 / scale;
        }
        // Invertible frame/mass transformation with angular-linear coupling.
        for (uint32_t d = 0; d < 3; ++d)
        {
            const double value = .15 * std::sin(double(node + d));
            frame[d * 6 + d + 3] = value;
            basis[size_t(node * 6 + d) * 6 + d + 3] = -value / (angular * linear);
        }
    }
    auto addRow = [&](uint32_t left, uint32_t right, uint32_t axis, double weight) {
        std::vector<std::pair<uint32_t, double>> entries;
        for (uint32_t d = 0; d < 6; ++d)
        {
            entries.push_back({left * 6 + d, frames[left][axis * 6 + d]});
            if (right < nodes) entries.push_back({right * 6 + d, -frames[right][axis * 6 + d]});
        }
        for (const auto& i : entries)
            for (const auto& j : entries)
                a[size_t(i.first) * n + j.first] += weight * i.second * j.second;
    };
    for (uint32_t node = 1; node < nodes; ++node)
        for (uint32_t axis = 0; axis < 6; ++axis)
            addRow(node - 1, node, axis, .5 + .2 * axis + .03 * (node % 5));
    if (anchored)
        for (uint32_t axis = 0; axis < 6; ++axis) addRow(0, nodes, axis, 1 + .2 * axis);
    return {sparse(a, n, n), basis};
}

void checkChain(uint32_t nodes, bool anchored)
{
    const auto input = chain(nodes, anchored);
    if (!anchored)
        for (uint32_t k = 0; k < 6; ++k)
        {
            Values mode(input.a.rows);
            for (uint32_t i = 0; i < input.a.rows; ++i) mode[i] = input.basis[size_t(i) * 6 + k];
            require(norm(multiplyVector(input.a, mode)) < 1e-13 * std::max(norm(mode), 1.), "Fixture rigid mode");
        }
    const auto hierarchy = buildConnected(input.a, input.basis, !anchored);
    require(hierarchy.maximumBasisReconstructionError < 1e-12, "Rigid basis reconstruction");
    Matrix current = input.a;
    for (const auto& level : hierarchy.levels)
    {
        close(dense(level.matrix), dense(current), 2e-11, "Exact Galerkin matrix");
        close(dense(level.restriction), transpose(dense(level.prolongation),
              level.prolongation.rows, level.prolongation.columns), 1e-14, "Restriction transpose");
        require(level.omega > 0 && level.omega * level.eigenvalueUpperBound < 2, "Smoothing stability interval");
        // Independent column-by-column Galerkin construction uses scalar
        // matvecs, not the builder's block sparse products.
        const uint32_t n = level.prolongation.columns;
        Values coarse(size_t(n) * n, 0);
        for (uint32_t column = 0; column < n; ++column)
        {
            Values unit(n, 0); unit[column] = 1;
            const auto values = multiplyVector(level.restriction, multiplyVector(current, multiplyVector(level.prolongation, unit)));
            for (uint32_t row = 0; row < n; ++row) coarse[size_t(row) * n + column] = values[row];
        }
        current = sparse(coarse, n, n);
    }
    const uint32_t n = hierarchy.coarseRows;
    const auto a = dense(current);
    const auto& inverse = hierarchy.coarseInverse;
    close(a, transpose(a, n, n), 1e-12, "Coarse symmetry");
    close(inverse, transpose(inverse, n, n), 1e-10, "Inverse symmetry");
    const auto ai = product(a, inverse, n);
    if (norm(a) == 0)
        require(norm(inverse) < 1e-25, "Isolated free node has no internal load");
    else
    {
        close(product(ai, a, n), a, 2e-9, "A inverse A = A");
        close(product(inverse, ai, n), inverse, 2e-9, "Inverse A inverse = inverse");
        close(ai, transpose(ai, n, n), 2e-9, "Orthogonal coarse projection");
    }
    double trace = 0;
    for (uint32_t i = 0; i < n; ++i) trace += ai[size_t(i) * n + i];
    require(std::abs(trace - (anchored ? n : n - 6)) < 1e-7, "Exact six free rigid modes");
    std::printf("chain nodes=%u anchored=%d levels=%zu setup_ms=%.6f passed\n",
                nodes, anchored, hierarchy.levels.size(), hierarchy.setupMilliseconds);
}

template<class F> void rejects(F f, const char* message)
{
    try { f(); } catch (const std::runtime_error&) { return; }
    throw std::runtime_error(message);
}

int main()
{
    try
    {
        for (uint32_t nodes : {1u, 2u, 29u, 30u, 64u, 256u})
            for (bool anchored : {false, true}) checkChain(nodes, anchored);
        auto input = chain(2, true);
        auto invalid = input.a; invalid.offsets[0] = 1;
        rejects([&]{ buildConnected(invalid, input.basis, false); }, "Accepted invalid CSR");
        invalid = input.a; invalid.indices[0] = invalid.columns;
        rejects([&]{ buildConnected(invalid, input.basis, false); }, "Accepted invalid column");
        auto basis = input.basis; basis[0] = std::numeric_limits<double>::quiet_NaN();
        rejects([&]{ buildConnected(input.a, basis, false); }, "Accepted nonfinite basis");
        invalid = input.a; for (double& value : invalid.values) value = -value;
        rejects([&]{ buildConnected(invalid, input.basis, false); }, "Accepted negative definite matrix");
        std::puts("All native hierarchy checks passed");
        return 0;
    }
    catch (const std::exception& error)
    {
        std::fprintf(stderr, "Native hierarchy test: %s\n", error.what());
        return 1;
    }
}
