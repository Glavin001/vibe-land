#!/usr/bin/env python3
"""Export one connected physical graph and CPU-built hierarchy for the CUDA proof.

Offline setup only. Output is a local little-endian binary fixture, not a game
asset/protocol. It includes the true operator and dense-reference bond solution
for independent validation after CUDA readback. Requires NumPy/SciPy.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import struct
import time

import numpy as np
from scipy.linalg import cho_solve
from multilevel_reference import Graph, Multilevel, solve


def write_array(file, array, dtype):
    file.write(np.asarray(array, dtype=dtype).tobytes(order='C'))


def write_matrix(file, matrix):
    matrix = matrix.tocsr()
    matrix.sort_indices()
    file.write(struct.pack('<III', *matrix.shape, matrix.nnz))
    write_array(file, matrix.indptr, '<u4')
    write_array(file, matrix.indices, '<u4')
    write_array(file, matrix.data, '<f8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--graph', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--release', action='store_true')
    parser.add_argument('--loads', choices=['gravity','random'], default='gravity')
    args = parser.parse_args()
    opener = gzip.open if args.graph.endswith('.gz') else open
    with opener(args.graph, 'rt') as file:
        scene = json.load(file)
    nodes, bonds = np.asarray(scene['nodes']), np.asarray(scene['bonds'])
    if args.release:
        bonds = bonds[np.all(nodes[bonds[:,:2].astype(np.int64),3]>0, axis=1)]
    start = time.monotonic()
    graph = Graph(nodes,bonds)
    assert len(np.unique(graph.components)) == 1, 'Export one connected component at a time'
    if args.loads == 'gravity':
        force = np.zeros((len(nodes),3)); force[:,1] = -nodes[:,3]*scene['gravity']
        moment = np.zeros_like(force)
    else:
        rng = np.random.default_rng(5489)
        force = rng.normal(size=(len(nodes),3))*nodes[:,3,None]
        moment = rng.normal(size=(len(nodes),3))*nodes[:,4,None]
    rhs = graph.input(force,moment)
    physical_input = rhs.copy()
    basis = graph.rigid_basis(np.arange(len(graph.active)))
    free = not graph.anchored.any()
    q = np.linalg.qr(basis, mode='reduced')[0] if free else np.empty((len(rhs),0))
    rhs -= q@(q.T@rhs)
    ml = Multilevel(graph.A,basis,free)
    inverse = cho_solve(ml.factor,np.eye(len(ml.factor[0])))
    if free:
        cq = ml.coarse_null
        projector = np.eye(len(inverse))-cq@cq.T
        inverse = projector@inverse@projector
    setup_seconds = time.monotonic()-start
    expected = solve(graph,force,moment)
    weights = np.column_stack((graph.mass*graph.length**2/graph.D[:,:3],
                               graph.mass*graph.length/graph.D[:,3:])).ravel()
    original_load = (weights*physical_input).reshape(-1,6)
    force_norm = np.hypot(np.linalg.norm(original_load[:,3:]),
                          np.linalg.norm(original_load[:,:3])/graph.length)
    out = Path(args.out)
    with out.open('wb') as file:
        file.write(b'BLSTMG01')
        file.write(struct.pack('<III',len(rhs),len(ml.levels),q.shape[1]))
        file.write(struct.pack('<dd',force_norm,force_norm*graph.length))
        for data in (rhs,weights,q):write_array(file,data,'<f8')
        write_matrix(file,graph.A)
        write_matrix(file,graph.B.T)
        write_array(file,expected['bond_solution'],'<f8')
        file.write(struct.pack('<I',len(inverse)))
        write_array(file,inverse,'<f8')
        for a,d,w,p in ml.levels:
            file.write(struct.pack('<d',w))
            for matrix in (a,d,p,p.T):write_matrix(file,matrix)
    manifest={'file':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
              'graph':args.graph,'graph_sha256':hashlib.sha256(Path(args.graph).read_bytes()).hexdigest(),
              'active_nodes':len(graph.active),'bonds':len(graph.bonds),'free':bool(free),
              'loads':args.loads,'offline_cpu_setup_seconds':setup_seconds,'levels':ml.trace,
              'reference_residual':expected['residual'],
              'reference_iterations':[v['iterations'] for v in expected['components']],
              'scope':'Offline hierarchy fixture only; no runtime topology-update implementation.'}
    out.with_suffix(out.suffix+'.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(manifest,indent=2))


if __name__=='__main__':main()
