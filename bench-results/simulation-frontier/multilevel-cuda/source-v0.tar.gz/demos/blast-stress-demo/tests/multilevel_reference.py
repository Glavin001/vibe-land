#!/usr/bin/env python3
"""CPU/double reference for physical-load multilevel solving; never used by the game.

Run with OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1. Requires NumPy and SciPy.
Without arguments, exercise independent free/anchored load fixtures. --graph
accepts gpu_stress_suite --export JSON (optionally gzipped). --release removes
anchor bonds to test the same building as a free fragment. Timings include a
Python/SciPy implementation and are not GPU performance predictions.
"""
import argparse
from dataclasses import dataclass
import gzip
import json
import time

import numpy as np
from scipy.linalg import cho_factor, cho_solve
from scipy.sparse import bsr_matrix, coo_matrix
from scipy.sparse.csgraph import connected_components
from scipy.sparse.linalg import LinearOperator, cg, eigsh


def diagonal_blocks(blocks):
    n, width, _ = blocks.shape
    return bsr_matrix((blocks, np.arange(n), np.arange(n+1)),
                      shape=(n*width, n*width)).tocsr()


def cross(r):
    x, y, z = r
    return np.array([[0., -z, y], [z, 0., -x], [-y, x, 0.]])


@dataclass
class Graph:
    nodes: np.ndarray  # x,y,z,mass,scalar inertia
    bonds: np.ndarray  # node0,node1,centroid xyz,column scale

    def __post_init__(self):
        self.ids = self.bonds[:, :2].astype(np.int64)
        assert np.all(self.ids == self.bonds[:, :2])
        assert np.all((self.ids >= 0) & (self.ids < len(self.nodes)))
        assert np.all(np.isfinite(self.nodes)) and np.all(np.isfinite(self.bonds))
        self.dynamic = self.nodes[:, 3] > 0
        assert np.all(self.nodes[self.dynamic, 4] > 0)
        assert np.all(self.bonds[:, 5] > 0)
        used = np.unique(self.ids)
        self.active = used[self.dynamic[used]]
        self.mapping = np.full(len(self.nodes), -1, dtype=np.int64)
        self.mapping[self.active] = np.arange(len(self.active))
        p0, p1 = self.nodes[self.ids[:, 0], :3], self.nodes[self.ids[:, 1], :3]
        d0, d1 = self.dynamic[self.ids[:, 0]], self.dynamic[self.ids[:, 1]]
        assert np.all(d0 | d1), 'Remove bonds between two immovable nodes'
        offsets = [.5 * (p1-p0), .5 * (p0-p1)]
        offsets[0][~d1] = self.bonds[~d1, 2:5] - p0[~d1]
        offsets[1][~d1] = -offsets[0][~d1]
        offsets[1][~d0] = self.bonds[~d0, 2:5] - p1[~d0]
        offsets[0][~d0] = -offsets[1][~d0]
        self.length = (np.linalg.norm(offsets[0][d0], axis=1).sum() +
                       np.linalg.norm(offsets[1][d1], axis=1).sum()) / (d0.sum()+d1.sum())
        if self.length == 0:
            self.length = 1.
        # Match the exported operator's all-dynamic-node geometric mass scale.
        self.mass = np.exp(np.log(self.nodes[self.dynamic, 3]).mean())
        inv = np.column_stack((np.sqrt(self.mass*self.length**2/self.nodes[self.active, 4]),
                               np.sqrt(self.mass/self.nodes[self.active, 3])))
        self.D = np.repeat(inv, 3, axis=1)
        rows, cols, values = [], [], []
        for side, mask in enumerate((d0, d1)):
            bs = np.flatnonzero(mask)
            ns = self.mapping[self.ids[bs, side]]
            r = offsets[side][bs] / self.length
            scale = self.bonds[bs, 5] * (1 if side == 0 else -1)
            for axis in range(6):
                rows.append(6*ns+axis); cols.append(6*bs+axis)
                values.append(self.D[ns, axis]*scale)
            # Coupling stores negative physical angular velocity. The angular
            # rows of B contain force cross arm, not arm cross force.
            for i, j, k, sign in ((0,1,2,1), (0,2,1,-1), (1,0,2,-1),
                                  (1,2,0,1), (2,0,1,1), (2,1,0,-1)):
                rows.append(6*ns+i); cols.append(6*bs+3+j)
                values.append(self.D[ns,i]*scale*r[:,k]*sign)
        shape = (6*len(self.active), 6*len(self.bonds))
        self.B = coo_matrix((np.concatenate(values), (np.concatenate(rows), np.concatenate(cols))),
                            shape=shape).tocsr()
        self.A = (self.B @ self.B.T).tocsr()
        dd = d0 & d1
        edges = self.mapping[self.ids[dd]]
        adjacency = coo_matrix((np.ones(2*len(edges)),
                               (edges.ravel(), edges[:, ::-1].ravel())),
                              shape=(len(self.active), len(self.active))).tocsr()
        _, self.components = connected_components(adjacency, directed=False)
        self.anchored = np.zeros(len(self.active), dtype=bool)
        self.anchored[self.mapping[self.ids[d0 & ~d1, 0]]] = True
        self.anchored[self.mapping[self.ids[d1 & ~d0, 1]]] = True

    def input(self, force, moment):
        n = self.nodes[self.active]
        return (np.column_stack((-moment[self.active]/n[:, 4, None],
                                 force[self.active]/(n[:, 3, None]*self.length))) / self.D).ravel()

    def rigid_basis(self, indices):
        nodes = self.nodes[self.active[indices]]
        center = np.average(nodes[:, :3], axis=0, weights=nodes[:, 3])
        modes = np.zeros((len(indices), 6, 6))
        modes[:, :3, :3] = np.eye(3)
        modes[:, 3:, 3:] = np.eye(3)
        for i, pos in enumerate(nodes[:, :3]):
            modes[i, 3:, :3] = cross((pos-center)/self.length)
        return (modes/self.D[indices, :, None]).reshape(-1, 6)

    def accelerations(self, rhs):
        scaled = rhs.reshape(-1, 6)*self.D
        return scaled[:, 3:]*self.length, -scaled[:, :3]

    def physical_residual(self, rhs, reference):
        # Norms in N and N m, no fitted load multiplier. A single physical
        # wrench norm handles both pure-force and pure-moment inputs.
        scale = np.column_stack((self.mass*self.length**2/self.D[:, :3],
                                 self.mass*self.length/self.D[:, 3:]))
        error = rhs.reshape(-1, 6)*scale
        load = reference.reshape(-1, 6)*scale
        fnorm = np.hypot(np.linalg.norm(load[:, 3:]), np.linalg.norm(load[:, :3])/self.length)
        mnorm = self.length*fnorm
        return {'force': float(np.linalg.norm(error[:, 3:])/max(fnorm, 1e-300)),
                'moment': float(np.linalg.norm(error[:, :3])/max(mnorm, 1e-300))}


class Multilevel:
    """Symmetric smoothed aggregation, exact Galerkin products, no dropping."""
    def __init__(self, matrix, basis, free):
        self.levels = []
        self.trace = []
        current = matrix
        for _ in range(8):
            nb = current.shape[0]//6
            if nb < 30:
                break
            blocks = current.tobsr(blocksize=(6,6))
            rows = np.repeat(np.arange(nb), np.diff(blocks.indptr))
            diagonal = blocks.data[blocks.indices == rows]
            assert len(diagonal) == nb
            inverse = diagonal_blocks(np.linalg.inv(diagonal))
            white = diagonal_blocks(np.linalg.inv(np.linalg.cholesky(diagonal)))
            # Reproducible initial vector for the setup-only eigenvalue estimate.
            rho = float(eigsh(white@current@white.T, k=1, which='LA', tol=1e-3,
                              v0=np.random.default_rng(0).normal(size=6*nb),
                              return_eigenvectors=False)[0])
            omega = 1/(rho*1.05)
            owner = np.full(nb, -1, dtype=np.int64)
            groups = []
            for i in range(nb):
                if owner[i] >= 0:
                    continue
                group, queue = [i], [i]
                owner[i] = len(groups)
                while queue and len(group) < 8:
                    v = queue.pop(0)
                    for j in blocks.indices[blocks.indptr[v]:blocks.indptr[v+1]]:
                        if owner[j] < 0:
                            owner[j] = len(groups)
                            group.append(int(j)); queue.append(int(j))
                            if len(group) == 8:
                                break
                groups.append(group)
            if len(groups) == nb:
                raise RuntimeError('Aggregation failed to reduce a connected component')
            rr, cc, vv, coarse_basis = [], [], [], []
            for i, group in enumerate(groups):
                dofs = (6*np.asarray(group)[:,None]+np.arange(6)).ravel()
                q, r = np.linalg.qr(basis[dofs], mode='reduced')
                coarse_basis.append(r)
                rr.append(np.repeat(dofs, 6)); cc.append(np.tile(6*i+np.arange(6), len(dofs)))
                vv.append(q.ravel())
            tentative = coo_matrix((np.concatenate(vv), (np.concatenate(rr), np.concatenate(cc))),
                                   shape=(6*nb, 6*len(groups))).tocsr()
            p = tentative - omega*(inverse@(current@tentative))
            next_matrix = (p.T@current@p).tocsr()
            # Remove only floating-point antisymmetry; retain every coefficient.
            next_matrix = (next_matrix+next_matrix.T)*.5
            self.trace.append({'blocks': nb, 'nnz': current.nnz, 'coarse_blocks': len(groups)})
            self.levels.append((current, inverse, omega, p))
            current, basis = next_matrix, np.vstack(coarse_basis)
        self.coarse_null = np.linalg.qr(basis, mode='reduced')[0] if free else None
        dense = current.toarray()
        if free:
            # Gauge fixing acts only in the known six-dimensional rigid space.
            # The physical right-hand side is projected, never clipped/pinned.
            dense += self.coarse_null @ self.coarse_null.T
        self.factor = cho_factor(dense)

    def cycle(self, rhs, level=0):
        if level == len(self.levels):
            q = self.coarse_null
            x = cho_solve(self.factor, rhs if q is None else rhs-q@(q.T@rhs))
            return x if q is None else x-q@(q.T@x)
        a, d, w, p = self.levels[level]
        x = np.zeros_like(rhs)
        for _ in range(2):
            x += w*(d@(rhs-a@x))
        x += p@self.cycle(p.T@(rhs-a@x), level+1)
        for _ in range(2):
            x += w*(d@(rhs-a@x))
        return x


def solve(graph, force, moment, rtol=1e-10):
    start = time.monotonic()
    rhs = graph.input(force, moment)
    internal, rigid, x = rhs.copy(), np.zeros_like(rhs), np.zeros_like(rhs)
    results = []
    for component in np.unique(graph.components):
        indices = np.flatnonzero(graph.components == component)
        dofs = (6*indices[:,None]+np.arange(6)).ravel()
        a = graph.A[dofs][:, dofs]
        basis = graph.rigid_basis(indices)
        free = not np.any(graph.anchored[indices])
        q = np.linalg.qr(basis, mode='reduced')[0] if free else None
        null_error = 0.
        if free:
            null_error = np.linalg.norm(graph.B[dofs].T@q)/max(np.linalg.norm(graph.B[dofs].data), 1e-300)
            assert null_error < 1e-12, null_error
            rigid[dofs] = q@(q.T@rhs[dofs])
            internal[dofs] -= rigid[dofs]
            # Independent Newton/Euler check of the removed rigid acceleration.
            nodes = graph.nodes[graph.active[indices]]
            f, m = force[graph.active[indices]], moment[graph.active[indices]]
            center = np.average(nodes[:,:3], axis=0, weights=nodes[:,3])
            offset = nodes[:,:3]-center
            inertia = np.eye(3)*nodes[:,4].sum()
            for mass, r in zip(nodes[:,3], offset):
                inertia += mass*(np.dot(r,r)*np.eye(3)-np.outer(r,r))
            alpha = np.linalg.solve(inertia, (m+np.cross(offset,f)).sum(axis=0))
            acceleration = f.sum(axis=0)/nodes[:,3].sum()+np.cross(alpha,offset)
            predicted = rigid[dofs].reshape(-1,6)*graph.D[indices]
            np.testing.assert_allclose(predicted[:,3:]*graph.length, acceleration, rtol=1e-10, atol=1e-10)
            np.testing.assert_allclose(-predicted[:,:3], np.broadcast_to(alpha,(len(indices),3)), rtol=1e-10, atol=1e-10)
        projected_norm = np.linalg.norm(internal[dofs])
        load_norm = np.linalg.norm(rhs[dofs])
        # This is an exact-reference shortcut for pure rigid loads: the error
        # is retained/reported, and the residual assertion below still applies.
        if projected_norm <= 1e-13*load_norm:
            results.append({'nodes': len(indices), 'free': free, 'iterations': 0,
                            'null_error': null_error, 'levels': []})
            continue
        setup = time.monotonic()
        ml = Multilevel(a, basis, free)
        def apply(v):
            return a@v if q is None else a@v+q@(q.T@v)
        def precondition(v):
            if q is None:
                return ml.cycle(v)
            null = q@(q.T@v)
            z = ml.cycle(v-null)
            return z-q@(q.T@z)+null
        pre = LinearOperator(a.shape, matvec=precondition, dtype=np.float64)
        operator = LinearOperator(a.shape, matvec=apply, dtype=np.float64)
        iterations = [0]
        def callback(_):
            iterations[0] += 1
        setup_seconds = time.monotonic()-setup
        solution, info = cg(operator, internal[dofs], M=pre, rtol=rtol, atol=0,
                            maxiter=256, callback=callback)
        if info != 0:
            raise RuntimeError(f'Component {component} failed convergence: {info}')
        x[dofs] = solution
        results.append({'nodes': len(indices), 'free': free, 'iterations': iterations[0],
                        'null_error': null_error, 'levels': ml.trace, 'setup_seconds': setup_seconds})
    residual = graph.physical_residual(internal-graph.A@x, rhs)
    assert max(residual.values()) < 2e-7, residual
    return {'components': results, 'residual': residual, 'cpu_seconds': time.monotonic()-start,
            'bond_solution': graph.B.T@x, 'rigid': rigid}


def fixture_tests():
    # Two free masses accelerated by a point load: a_COM=8/(1+3)=2,
    # so the transmitted internal force is 8-1*2=6 N.
    nodes = np.array([[0,0,0,1,1], [2,0,0,3,2]], dtype=float)
    bonds = np.array([[0,1,1,0,0,1]], dtype=float)
    graph = Graph(nodes, bonds)
    force = np.array([[8.,0,0], [0,0,0]])
    result = solve(graph, force, np.zeros((2,3)))
    physical = result['bond_solution'].reshape(-1,6)[0,3:]*graph.mass*graph.length
    np.testing.assert_allclose(physical, [6.,0,0], rtol=1e-10, atol=1e-10)
    linear, angular = graph.accelerations(result['rigid'])
    np.testing.assert_allclose(linear, [[2,0,0],[2,0,0]], atol=1e-10)
    np.testing.assert_allclose(angular, 0, atol=1e-10)
    print('PASS free unequal-mass point load: 6 N transmitted, 2 m/s^2 rigid acceleration')
    result = solve(graph, np.zeros((2,3)), np.array([[0,0,4.], [0,0,0]]))
    linear, angular = graph.accelerations(result['rigid'])
    np.testing.assert_allclose(angular[:,2], 2/3, atol=1e-10)
    np.testing.assert_allclose(linear, [[0,-1,0],[0,1/3,0]], atol=1e-10)
    print('PASS free off-center couple: alpha=2/3 rad/s^2, orbital inertia retained')
    gravity = np.array([0.,-9.81,0])
    result = solve(graph, nodes[:,3,None]*gravity, np.zeros((2,3)))
    np.testing.assert_allclose(result['bond_solution'], 0, atol=1e-12)
    print('PASS free gravity produces rigid acceleration and zero internal bond load')
    # Anchor first node; same positive force on node1 requires full 8 N reaction.
    anchored = nodes.copy(); anchored[0,3:] = 0
    graph = Graph(anchored,bonds)
    result = solve(graph, force[::-1], np.zeros((2,3)))
    physical = result['bond_solution'].reshape(-1,6)[0,3:]*graph.mass*graph.length
    np.testing.assert_allclose(physical, [-8.,0,0], rtol=1e-10, atol=1e-10)
    print('PASS anchored load retains complete 8 N reaction')
    # A loaded free rod drives the actual multilevel path. Compare against a
    # dense minimum-norm least-squares solve of B, independently of PCG/AMG.
    n = 40
    nodes = np.column_stack((np.arange(n), np.zeros((n,2)),
                             1+np.arange(n)%5, .7+.1*(np.arange(n)%3)))
    bonds = np.column_stack((np.arange(n-1), np.arange(1,n),
                             np.arange(n-1)+.5, np.zeros((n-1,2)), np.ones(n-1)))
    graph = Graph(nodes,bonds)
    force = np.random.default_rng(11).normal(size=(n,3))
    moment = np.random.default_rng(17).normal(size=(n,3))
    result = solve(graph,force,moment)
    reference = np.linalg.lstsq(graph.B.toarray(),graph.input(force,moment),rcond=None)[0]
    np.testing.assert_allclose(result['bond_solution'],reference,rtol=2e-7,atol=2e-8)
    print('PASS free heterogeneous rod: multilevel bond loads match dense minimum-norm reference',
          json.dumps({k:v for k,v in result.items() if k not in ('bond_solution','rigid')}))
    # Split into two free components and one anchored component. Recompute each
    # null space after removing bonds; gravity must not pin the detached pieces.
    nodes[0,3:] = 0
    bonds = np.delete(bonds,[9,24],axis=0)
    graph = Graph(nodes,bonds)
    result = solve(graph,force,moment)
    reference = np.linalg.lstsq(graph.B.toarray(),graph.input(force,moment),rcond=None)[0]
    np.testing.assert_allclose(result['bond_solution'],reference,rtol=2e-7,atol=2e-8)
    assert sorted(c['free'] for c in result['components']) == [False,True,True]
    print('PASS mixed anchored/free fracture components: independent rigid motion and bond loads')
    # Rotation/translation must change only the coordinate representation, not
    # the bond solution or which component is allowed to accelerate freely.
    axis = np.array([1.,2.,3.]); axis /= np.linalg.norm(axis)
    skew = cross(axis)
    rotation = np.eye(3)+np.sin(.7)*skew+(1-np.cos(.7))*(skew@skew)
    rotated_nodes, rotated_bonds = nodes.copy(), bonds.copy()
    shift = np.array([900.,-300.,400.])
    rotated_nodes[:,:3] = nodes[:,:3]@rotation.T+shift
    rotated_bonds[:,2:5] = bonds[:,2:5]@rotation.T+shift
    transformed = solve(Graph(rotated_nodes,rotated_bonds),force@rotation.T,moment@rotation.T)
    expected = result['bond_solution'].reshape(-1,3)@rotation.T
    np.testing.assert_allclose(transformed['bond_solution'].reshape(-1,3),expected,
                               rtol=3e-7,atol=3e-8)
    print('PASS rotated/translated mixed components preserve force and moment covariance')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--graph')
    parser.add_argument('--release', action='store_true', help='Remove anchor bonds for free-building validation')
    parser.add_argument('--loads', choices=['gravity','random'], default='gravity')
    args = parser.parse_args()
    if not args.graph:
        fixture_tests()
        return
    opener = gzip.open if args.graph.endswith('.gz') else open
    with opener(args.graph, 'rt') as file:
        scene = json.load(file)
    nodes, bonds = np.asarray(scene['nodes']), np.asarray(scene['bonds'])
    if args.release:
        bonds = bonds[np.all(nodes[bonds[:,:2].astype(np.int64),3] > 0,axis=1)]
    graph = Graph(nodes,bonds)
    if args.loads == 'gravity':
        force = np.zeros((len(nodes),3)); force[:,1] = -nodes[:,3]*scene['gravity']
        moment = np.zeros_like(force)
    else:
        rng = np.random.default_rng(5489)
        force = rng.normal(size=(len(nodes),3))*nodes[:,3,None]
        moment = rng.normal(size=(len(nodes),3))*nodes[:,4,None]
    result = solve(graph,force,moment)
    del result['bond_solution'], result['rigid']
    result.update({'active_nodes': len(graph.active), 'bonds': len(bonds),
                   'released': args.release, 'loads': args.loads, 'scope': 'CPU/double reference only'})
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
