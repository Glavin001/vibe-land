// Offline CUDA proof of the physical multilevel solve. Hierarchy construction
// is performed by export_multilevel.py; this is not the production solver.
#include <cuda_runtime.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <limits>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#define CUDA(call) do { const auto e=(call); if(e!=cudaSuccess) throw std::runtime_error(std::string(#call)+": "+cudaGetErrorString(e)); } while(0)
constexpr int Block=256;
struct State { double rho,alpha,beta,rhs2,residual2,tolerance2; int done,failed,iterations; };

template<class T> struct Buffer {
    T* data=nullptr; size_t size=0;
    Buffer()=default;
    explicit Buffer(size_t n):size(n) { if(n) CUDA(cudaMalloc(&data,n*sizeof(T))); }
    ~Buffer(){cudaFree(data);}
    Buffer(const Buffer&)=delete; Buffer& operator=(const Buffer&)=delete;
    Buffer(Buffer&& b) noexcept:data(b.data),size(b.size){b.data=nullptr;b.size=0;}
    Buffer& operator=(Buffer&& b) noexcept {std::swap(data,b.data);std::swap(size,b.size);return *this;}
    void upload(const std::vector<T>& v,cudaStream_t s) {if(v.size()!=size)throw std::runtime_error("upload size"); if(size)CUDA(cudaMemcpyAsync(data,v.data(),size*sizeof(T),cudaMemcpyHostToDevice,s));}
};
struct Reader {
    std::ifstream f; uint64_t remaining;
    explicit Reader(const char* name):f(name,std::ios::binary|std::ios::ate) {
        if(!f)throw std::runtime_error("open fixture"); remaining=uint64_t(f.tellg());f.seekg(0);
        char magic[8];read(magic,8);if(std::string(magic,8)!="BLSTMG01")throw std::runtime_error("fixture version");
    }
    void read(void* p,uint64_t n){if(n>remaining)throw std::runtime_error("truncated fixture");f.read(static_cast<char*>(p),n);if(!f)throw std::runtime_error("read fixture");remaining-=n;}
    template<class T>T scalar(){T v;read(&v,sizeof(T));return v;}
    template<class T>std::vector<T> array(uint64_t n){if(n>remaining/sizeof(T))throw std::runtime_error("fixture array size");std::vector<T> v(n);read(v.data(),n*sizeof(T));return v;}
};
struct Matrix {
    uint32_t rows,cols; std::vector<uint32_t> offsets,indices; std::vector<double> values;
    explicit Matrix(Reader& r) {
        rows=r.scalar<uint32_t>();cols=r.scalar<uint32_t>();const uint32_t nnz=r.scalar<uint32_t>();
        offsets=r.array<uint32_t>(uint64_t(rows)+1);indices=r.array<uint32_t>(nnz);values=r.array<double>(nnz);
        if(offsets.front()!=0||offsets.back()!=nnz||!std::is_sorted(offsets.begin(),offsets.end()))throw std::runtime_error("CSR offsets");
        for(auto i:indices)if(i>=cols)throw std::runtime_error("CSR column");
        for(double v:values)if(!std::isfinite(v))throw std::runtime_error("nonfinite matrix");
    }
    std::vector<double> multiply(const std::vector<double>& x) const {
        if(x.size()!=cols)throw std::runtime_error("matvec dimensions");std::vector<double> y(rows);
        for(uint32_t i=0;i<rows;++i)for(uint32_t j=offsets[i];j<offsets[i+1];++j)y[i]+=values[j]*x[indices[j]];
        return y;
    }
};
struct HostLevel { double omega; Matrix a,d,p,pt; explicit HostLevel(Reader& r):omega(r.scalar<double>()),a(r),d(r),p(r),pt(r){} };
struct Fixture {
    uint32_t n,levelCount,qcols,coarse;
    double forceNorm,momentNorm;
    std::vector<double> rhs,weights,q,expected,inverse;
    Matrix a,bt; std::vector<HostLevel> levels;
    explicit Fixture(Reader& r):n(r.scalar<uint32_t>()),levelCount(r.scalar<uint32_t>()),qcols(r.scalar<uint32_t>()),
        forceNorm(r.scalar<double>()),momentNorm(r.scalar<double>()),rhs(r.array<double>(n)),weights(r.array<double>(n)),q(r.array<double>(uint64_t(n)*qcols)),a(r),bt(r) {
        if(!n||n%6||qcols>6||a.rows!=n||a.cols!=n||bt.cols!=n)throw std::runtime_error("fixture dimensions");
        expected=r.array<double>(bt.rows);coarse=r.scalar<uint32_t>();inverse=r.array<double>(uint64_t(coarse)*coarse);
        uint32_t size=n;
        for(uint32_t i=0;i<levelCount;++i){levels.emplace_back(r);const auto& l=levels.back();
            if(l.a.rows!=size||l.a.cols!=size||l.d.rows!=size||l.d.cols!=size||l.p.rows!=size||l.pt.cols!=size||l.p.cols!=l.pt.rows)throw std::runtime_error("hierarchy dimensions");size=l.p.cols;}
        if(size!=coarse||r.remaining)throw std::runtime_error("coarse dimensions/trailing bytes");
    }
};
template<class T>struct DeviceMatrix {
    uint32_t rows,cols;Buffer<uint32_t> offsets,indices;Buffer<T> values;
    DeviceMatrix(const Matrix& m,cudaStream_t s):rows(m.rows),cols(m.cols),offsets(m.offsets.size()),indices(m.indices.size()),values(m.values.size()){
        offsets.upload(m.offsets,s);indices.upload(m.indices,s);
        std::vector<T> v(m.values.begin(),m.values.end());values.upload(v,s);
        // Pageable temporary upload must be consumed before v's storage dies.
        CUDA(cudaStreamSynchronize(s));
    }
};
__device__ double warpSum(double x){for(int d=16;d;d/=2)x+=__shfl_down_sync(0xffffffffu,x,d);return x;}
template<class T>__global__ void csrKernel(uint32_t rows,const uint32_t* off,const uint32_t* idx,const T* val,const double* x,double* y,const double* base,double alpha,double beta,const State* st){
    if(st->done)return;const uint32_t row=(blockIdx.x*blockDim.x+threadIdx.x)/32;const int lane=threadIdx.x%32;
    if(row>=rows)return;double value=0;
    for(uint32_t j=off[row]+lane;j<off[row+1];j+=32)value+=double(val[j])*x[idx[j]];
    value=warpSum(value);if(!lane)y[row]=alpha*value+(base?beta*base[row]:0.);
}
__global__ void zeroKernel(double* x,uint32_t n,const State* st){if(st->done)return;const auto i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n)x[i]=0;}
__global__ void dotKernel(const double* x,const double* y,double* partial,uint32_t n,const State* st){
    if(st->done)return;__shared__ double sums[Block];const auto i=blockIdx.x*blockDim.x+threadIdx.x;
    sums[threadIdx.x]=i<n?x[i]*y[i]:0.;__syncthreads();
    for(int d=Block/2;d;d/=2){if(threadIdx.x<d)sums[threadIdx.x]+=sums[threadIdx.x+d];__syncthreads();}
    if(!threadIdx.x)partial[blockIdx.x]=sums[0];
}
__global__ void finishDot(const double* partial,uint32_t count,State* st,int mode){
    if(st->done)return;__shared__ double sums[Block];double v=0;for(uint32_t i=threadIdx.x;i<count;i+=Block)v+=partial[i];sums[threadIdx.x]=v;__syncthreads();
    for(int d=Block/2;d;d/=2){if(threadIdx.x<d)sums[threadIdx.x]+=sums[threadIdx.x+d];__syncthreads();}
    if(threadIdx.x)return;v=sums[0];
    if(!isfinite(v)){st->done=st->failed=1;return;}
    if(mode==0){if(v<=0||st->rho<=0){st->done=st->failed=1;return;}st->alpha=st->rho/v;}
    else if(mode==1){st->residual2=v;++st->iterations;if(v<=st->rhs2*st->tolerance2)st->done=1;}
    else {if(v<=0){st->done=st->failed=1;return;}st->beta=mode==3?0.:v/st->rho;st->rho=v;}
}
__global__ void updateXR(double* x,double* r,const double* p,const double* ap,uint32_t n,const State* st){
    if(st->done)return;const auto i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n){x[i]+=st->alpha*p[i];r[i]-=st->alpha*ap[i];}
}
__global__ void updateP(double* p,const double* z,uint32_t n,const State* st){if(st->done)return;const auto i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n)p[i]=z[i]+st->beta*p[i];}
__global__ void qDots(const double* q,const double* x,double* partial,uint32_t n,uint32_t cols,const State* st){
    if(st->done)return;__shared__ double sums[Block];const auto i=blockIdx.x*blockDim.x+threadIdx.x;const auto col=blockIdx.y;
    sums[threadIdx.x]=i<n?q[size_t(i)*cols+col]*x[i]:0.;__syncthreads();
    for(int d=Block/2;d;d/=2){if(threadIdx.x<d)sums[threadIdx.x]+=sums[threadIdx.x+d];__syncthreads();}
    if(!threadIdx.x)partial[size_t(col)*gridDim.x+blockIdx.x]=sums[0];
}
__global__ void qFinish(const double* partial,double* coeff,uint32_t blocks,uint32_t cols,const State* st){
    if(st->done||threadIdx.x>=cols)return;double sum=0;for(uint32_t i=0;i<blocks;++i)sum+=partial[size_t(threadIdx.x)*blocks+i];coeff[threadIdx.x]=sum;
}
__global__ void project(const double* input,double* output,const double* q,const double* c1,const double* c2,uint32_t n,uint32_t cols,double sign,const State* st){
    if(st->done)return;const auto i=blockIdx.x*blockDim.x+threadIdx.x;if(i>=n)return;double v=input[i];
    for(uint32_t j=0;j<cols;++j)v+=q[size_t(i)*cols+j]*(sign*c1[j]+(c2?c2[j]:0.));output[i]=v;
}
template<class T>__global__ void denseKernel(const T* matrix,const double* input,double* output,uint32_t n,const State* st){
    if(st->done)return;const auto row=(blockIdx.x*blockDim.x+threadIdx.x)/32;const auto lane=threadIdx.x%32;if(row>=n)return;
    double sum=0;for(uint32_t j=lane;j<n;j+=32)sum+=double(matrix[size_t(row)*n+j])*input[j];sum=warpSum(sum);if(!lane)output[row]=sum;
}
template<class T>struct Level {double omega;DeviceMatrix<T>a,d,p,pt;Buffer<double> residual,coarseRhs,coarseX;
    Level(const HostLevel& l,cudaStream_t s):omega(l.omega),a(l.a,s),d(l.d,s),p(l.p,s),pt(l.pt,s),residual(l.a.rows),coarseRhs(l.p.cols),coarseX(l.p.cols){} };

template<class T>class Solver {
    const Fixture& f; cudaStream_t stream{};cudaGraph_t graph{};cudaGraphExec_t executable{};cudaEvent_t start{},stop{};
    DeviceMatrix<double> a;
    Buffer<double> rhs,q,x,r,p,z,ap,projected,parts,qparts,coeffR,coeffZ,coeffP;
    Buffer<T> inverse;Buffer<State> state;std::vector<Level<T>> levels;uint32_t blocks;
    template<class V>void multiply(const DeviceMatrix<V>& m,const double* in,double* out,const double* base=nullptr,double alpha=1.,double beta=0.){
        csrKernel<<<(uint64_t(m.rows)*32+Block-1)/Block,Block,0,stream>>>(m.rows,m.offsets.data,m.indices.data,m.values.data,in,out,base,alpha,beta,state.data);
    }
    void dots(const double* v,double* coeff){qDots<<<dim3(blocks,f.qcols),Block,0,stream>>>(q.data,v,qparts.data,f.n,f.qcols,state.data);qFinish<<<1,32,0,stream>>>(qparts.data,coeff,blocks,f.qcols,state.data);}
    void dot(const double* u,const double* v,int mode){dotKernel<<<blocks,Block,0,stream>>>(u,v,parts.data,f.n,state.data);finishDot<<<1,Block,0,stream>>>(parts.data,blocks,state.data,mode);}
    void cycle(size_t i,const double* input,double* output){
        if(i==levels.size()){denseKernel<<<(uint64_t(f.coarse)*32+Block-1)/Block,Block,0,stream>>>(inverse.data,input,output,f.coarse,state.data);return;}
        auto& l=levels[i];zeroKernel<<<(l.a.rows+Block-1)/Block,Block,0,stream>>>(output,l.a.rows,state.data);
        auto smooth=[&]{multiply(l.a,output,l.residual.data,input,-1.,1.);multiply(l.d,l.residual.data,output,output,l.omega,1.);};
        smooth();smooth();multiply(l.a,output,l.residual.data,input,-1.,1.);multiply(l.pt,l.residual.data,l.coarseRhs.data);
        cycle(i+1,l.coarseRhs.data,l.coarseX.data);multiply(l.p,l.coarseX.data,output,output,1.,1.);smooth();smooth();
    }
    void precondition(){
        if(!f.qcols){cycle(0,r.data,z.data);return;}
        dots(r.data,coeffR.data);project<<<blocks,Block,0,stream>>>(r.data,projected.data,q.data,coeffR.data,nullptr,f.n,f.qcols,-1.,state.data);
        cycle(0,projected.data,z.data);dots(z.data,coeffZ.data);
        project<<<blocks,Block,0,stream>>>(z.data,z.data,q.data,coeffZ.data,coeffR.data,f.n,f.qcols,-1.,state.data);
    }
    void iteration(){
        multiply(a,p.data,ap.data);
        if(f.qcols){dots(p.data,coeffP.data);project<<<blocks,Block,0,stream>>>(ap.data,ap.data,q.data,coeffP.data,nullptr,f.n,f.qcols,1.,state.data);}
        dot(p.data,ap.data,0);updateXR<<<blocks,Block,0,stream>>>(x.data,r.data,p.data,ap.data,f.n,state.data);
        dot(r.data,r.data,1);precondition();dot(r.data,z.data,2);updateP<<<blocks,Block,0,stream>>>(p.data,z.data,f.n,state.data);
    }
public:
    // stream is created first through the initializer helper so matrix upload
    // never silently uses another stream. All per-solve storage is persistent.
    static cudaStream_t newStream(){cudaStream_t s;CUDA(cudaStreamCreateWithFlags(&s,cudaStreamNonBlocking));return s;}
    explicit Solver(const Fixture& input):f(input),stream(newStream()),a(f.a,stream),rhs(f.n),q(f.q.size()),x(f.n),r(f.n),p(f.n),z(f.n),ap(f.n),projected(f.n),parts((f.n+Block-1)/Block),qparts(size_t((f.n+Block-1)/Block)*f.qcols),coeffR(f.qcols),coeffZ(f.qcols),coeffP(f.qcols),inverse(f.inverse.size()),state(1),blocks((f.n+Block-1)/Block){
        rhs.upload(f.rhs,stream);q.upload(f.q,stream);std::vector<T> ci(f.inverse.begin(),f.inverse.end());inverse.upload(ci,stream);
        for(const auto& l:f.levels)levels.emplace_back(l,stream);
        CUDA(cudaStreamSynchronize(stream));CUDA(cudaEventCreate(&start));CUDA(cudaEventCreate(&stop));
        CUDA(cudaStreamBeginCapture(stream,cudaStreamCaptureModeThreadLocal));iteration();CUDA(cudaStreamEndCapture(stream,&graph));
        CUDA(cudaGraphInstantiate(&executable,graph,0));
    }
    ~Solver(){cudaGraphExecDestroy(executable);cudaGraphDestroy(graph);cudaEventDestroy(start);cudaEventDestroy(stop);cudaStreamDestroy(stream);}
    bool run(int trial,int maxIterations,double tolerance,bool useGraph){
        State initial{};for(double v:f.rhs)initial.rhs2+=v*v;initial.residual2=initial.rhs2;initial.tolerance2=tolerance*tolerance;initial.done=initial.rhs2==0;
        const auto wall=std::chrono::steady_clock::now();CUDA(cudaEventRecord(start,stream));
        CUDA(cudaMemcpyAsync(state.data,&initial,sizeof(initial),cudaMemcpyHostToDevice,stream));
        CUDA(cudaMemcpyAsync(r.data,rhs.data,f.n*sizeof(double),cudaMemcpyDeviceToDevice,stream));
        CUDA(cudaMemsetAsync(x.data,0,f.n*sizeof(double),stream));precondition();dot(r.data,z.data,3);
        CUDA(cudaMemcpyAsync(p.data,z.data,f.n*sizeof(double),cudaMemcpyDeviceToDevice,stream));
        State observed=initial;int submitted=0;
        while(!observed.done&&submitted<maxIterations){
            const int batch=std::min(8,maxIterations-submitted);
            for(int k=0;k<batch;++k){if(useGraph)CUDA(cudaGraphLaunch(executable,stream));else iteration();}
            submitted+=batch;CUDA(cudaMemcpyAsync(&observed,state.data,sizeof(observed),cudaMemcpyDeviceToHost,stream));CUDA(cudaStreamSynchronize(stream));
        }
        CUDA(cudaEventRecord(stop,stream));CUDA(cudaEventSynchronize(stop));float elapsed;CUDA(cudaEventElapsedTime(&elapsed,start,stop));
        const double wallMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-wall).count();
        std::vector<double> solution(f.n);CUDA(cudaMemcpy(solution.data(),x.data,f.n*sizeof(double),cudaMemcpyDeviceToHost));
        const auto actual=f.a.multiply(solution);const auto bonds=f.bt.multiply(solution);
        double ef=0,em=0,bondError=0,bondNorm=0,bondMax=0,refMax=0;
        for(uint32_t i=0;i<f.n;++i){const double e=(f.rhs[i]-actual[i])*f.weights[i];if(i%6<3)em+=e*e;else ef+=e*e;}
        for(size_t i=0;i<bonds.size();++i){const double e=bonds[i]-f.expected[i];bondError+=e*e;bondNorm+=f.expected[i]*f.expected[i];bondMax=std::max(bondMax,std::abs(e));refMax=std::max(refMax,std::abs(f.expected[i]));}
        const double force=std::sqrt(ef)/std::max(f.forceNorm,1e-300),moment=std::sqrt(em)/std::max(f.momentNorm,1e-300),bondRelative=std::sqrt(bondError/std::max(bondNorm,1e-300));
        const bool passed=observed.done&&!observed.failed&&std::isfinite(force)&&std::isfinite(moment)&&std::isfinite(bondRelative)&&force<2e-7&&moment<2e-7&&bondRelative<2e-6;
        std::printf("{\"trial\":%d,\"passed\":%s,\"iterations\":%d,\"submitted\":%d,\"cuda_solve_ms\":%.6f,\"wall_solve_ms\":%.6f,\"force_residual\":%.12g,\"moment_residual\":%.12g,\"bond_relative_error\":%.12g,\"bond_max_error_over_peak\":%.12g,\"recurrence_relative_residual\":%.12g,\"failed\":%d}\n",trial,passed?"true":"false",observed.iterations,submitted,elapsed,wallMs,force,moment,bondRelative,bondMax/std::max(refMax,1e-300),std::sqrt(observed.residual2/std::max(observed.rhs2,1e-300)),observed.failed);
        return passed;
    }
};
template<class T>int benchmark(const Fixture& f,int repeats,int iters,double tol,bool graphs){
    const auto begin=std::chrono::steady_clock::now();Solver<T> solver(f);
    const double setup=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
    cudaDeviceProp prop;CUDA(cudaGetDeviceProperties(&prop,0));
    std::printf("{\"gpu\":\"%s\",\"operator\":\"double\",\"preconditioner_storage\":\"%s\",\"vectors_and_accumulation\":\"double\",\"cuda_graph\":%s,\"device_setup_upload_graph_ms\":%.6f,\"rows\":%u,\"free\":%s,\"levels\":%u,\"scope\":\"offline CPU-built hierarchy; no game integration\"}\n",prop.name,sizeof(T)==8?"double":"float",graphs?"true":"false",setup,f.n,f.qcols?"true":"false",f.levelCount);
    bool pass=true;for(int i=0;i<repeats;++i)pass=solver.run(i,iters,tol,graphs)&&pass;return pass?0:1;
}
int main(int argc,char** argv){try{
    if(argc<2)throw std::runtime_error("usage: multilevel_gpu_test FIXTURE [--float-preconditioner] [--no-graph] [--solves N] [--iterations N] [--tolerance N]");
    bool mixed=false,graph=true;int solves=4,iters=256;double tolerance=1e-10;
    for(int i=2;i<argc;++i){const std::string arg=argv[i];
        if(arg=="--float-preconditioner")mixed=true;else if(arg=="--no-graph")graph=false;
        else if(arg=="--solves"&&i+1<argc)solves=std::stoi(argv[++i]);else if(arg=="--iterations"&&i+1<argc)iters=std::stoi(argv[++i]);else if(arg=="--tolerance"&&i+1<argc)tolerance=std::stod(argv[++i]);else throw std::runtime_error("unknown/incomplete option");}
    if(solves<1||iters<1||!std::isfinite(tolerance)||tolerance<=0)throw std::runtime_error("invalid solve parameters");
    Reader reader(argv[1]);Fixture fixture(reader);
    return mixed?benchmark<float>(fixture,solves,iters,tolerance,graph):benchmark<double>(fixture,solves,iters,tolerance,graph);
}catch(const std::exception& e){std::fprintf(stderr,"multilevel CUDA test: %s\n",e.what());return 2;}}
